const settings = {
    apiUrl: '#',
  };
  
  export default settings;